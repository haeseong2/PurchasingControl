# Cursor Phase 프롬프트 모음

## Phase 1
이 문서 기준으로 Expo React Native TypeScript 프로젝트를 생성하고, app/ src/ 구조를 만들고, README를 생성해줘.

## Phase 2
제공된 schema.sql 기준으로 SQLite bootstrap과 테이블 생성을 구현해줘. notebook_groups와 app_entitlements를 포함해줘.

## Phase 3
HomeScreen을 만들어줘. TOPIK 1~6급 카드와 My Notebook 카드를 보여주고, 4~6급은 free 상태에서 잠금 표시가 가능해야 해. theme toggle도 넣어줘.

## Phase 4
LevelScreen과 StepCard를 만들어줘. free 사용자는 4~6급 접근이 잠겨야 해.

## Phase 5
StudyScreen을 만들어줘. Known / Unknown / Reveal Answer 버튼을 구현하고, free와 premium reveal 규칙을 분기해줘.

## Phase 6
Notebook 메인 화면을 만들어줘. 목록, 검색, 정렬, 직접 추가, 그룹 목록을 구현해줘.

## Phase 7
Notebook 그룹 기능을 만들어줘. 그룹 생성, 그룹 상세 화면, 단어를 그룹에 추가하는 구조를 구현해줘.

## Phase 8
Notebook 학습 화면을 만들어줘. notebook 전체 학습과 그룹별 학습을 모두 지원해줘.

## Phase 9
xlsx 기반 notebook export/import를 구현해줘. premium만 가능해야 하고, import 후 그룹 배치가 가능해야 해.

## Phase 10
light/dark/system theme를 구현하고 저장해줘.

## Phase 11
14일 trial 계산, premium 화면, purchasePremium / restorePremium 서비스 틀을 구현해줘.
