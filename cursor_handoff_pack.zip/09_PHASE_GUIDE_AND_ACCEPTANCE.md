# Phase 가이드 및 완료 기준

이 문서는 **Cursor로 실제 작업할 때 어떤 순서로 진행하고, 각 단계가 끝났다고 판단하는 기준이 무엇인지** 설명합니다.

---

## 전체 규칙
- 한 번에 하나의 Phase만 진행
- Phase 종료 후 결과 확인
- 정의한 기준과 맞으면 다음 Phase 진행
- 안 맞으면 수정 후에만 다음 Phase 진행

---

## Phase 1 — 프로젝트 초기 세팅
### 목표
- Expo + React Native + TypeScript + Expo Router 프로젝트 뼈대 생성
- 기본 폴더 구조 생성
- 필요한 패키지 설치

### 꼭 지켜야 할 것
- 웹 프로젝트로 만들지 말 것
- app/ 구조와 src/ 구조를 분리할 것
- README에 설치/실행 방법 적을 것

### 완료 기준
- 프로젝트가 실행 가능
- app/와 src/ 폴더 구조가 문서와 일치
- package.json, app.json, eas.json 존재

---

## Phase 2 — DB 구축
### 목표
- SQLite bootstrap 구현
- schema.sql 기준으로 테이블 생성

### 꼭 지켜야 할 것
- DB 로직을 화면 파일 안에 직접 쓰지 말 것
- app_preferences 테이블 포함할 것
- words / user_word_progress 분리할 것

### 완료 기준
- 앱 첫 실행 시 테이블이 생성됨
- DB 연결 오류 없음
- seed 삽입 구조 준비됨

---

## Phase 3 — HomeScreen
### 목표
- 첫 화면에 1급~6급 + 나만의 단어장 카드 표시
- theme toggle 추가

### 꼭 지켜야 할 것
- 카드 순서 정확히 지킬 것
- 스크롤형 세로 레이아웃 유지
- 너무 정보 많지 않게 단순하게 구성

### 완료 기준
- 첫 화면이 문서와 같은 카드 구조로 보임
- 다크/라이트 토글 위치 확인 가능

---

## Phase 4 — LevelScreen / Step 카드
### 목표
- 급수 클릭 시 해당 Step 리스트 표시

### 꼭 지켜야 할 것
- Step 제목, 범위, 진행률, 남은 모름 수 표시
- 문제 버튼은 placeholder여도 됨

### 완료 기준
- Step 카드들이 세로 목록으로 표시됨
- 클릭 시 Step 학습 화면으로 이동 가능

---

## Phase 5 — StudyScreen
### 목표
- 학습 핵심 로직 구현
- 알고있음 / 모름 / 정답 보기 버튼 동작

### 꼭 지켜야 할 것
- 정답 보기 누른다고 known 처리하지 말 것
- 모름 단어는 review queue로 보내기
- review queue 빌 때까지 반복
- 별표는 우상단 고정
- 중요한 로직에 한국어 주석 달 것

### 완료 기준
- 단어 카드 1개씩 표시됨
- 3개 버튼 동작함
- 뜻/예문 표시됨
- 모름 반복됨
- Step 완료 판정 동작함

---

## Phase 6 — NotebookScreen
### 목표
- 나만의 단어장 목록 화면 구현
- 검색 / 정렬 / import/export 안내 문구

### 꼭 지켜야 할 것
- import/export 안내 문구 명확히 표시
- empty state 준비

### 완료 기준
- 별표한 단어가 목록에 보임
- 검색/정렬 동작함

---

## Phase 7 — NotebookStudyScreen
### 목표
- 나만의 단어장도 같은 학습 UX 사용

### 꼭 지켜야 할 것
- 일반 Step 학습 화면과 UX 통일
- 3개 버튼 모두 있음
- reveal → 뜻/예문 표시

### 완료 기준
- notebook 단어도 학습 가능
- 모름 반복 가능

---

## Phase 8 — Excel import/export
### 목표
- notebook Excel 다운로드/업로드 구현

### 꼭 지켜야 할 것
- 템플릿 컬럼 정확히 맞출 것
- 예시 row 포함할 것
- field guide 시트 포함할 것
- import시 컬럼 검증 및 한국어 주석 추가

### 완료 기준
- export한 파일이 템플릿 형식과 맞음
- import하면 notebook에 단어가 추가됨

---

## Phase 9 — Theme
### 목표
- light/dark/system 테마 저장 및 적용

### 꼭 지켜야 할 것
- 배경/카드/텍스트 대비 확인
- 다크모드에서 버튼 가독성 확인

### 완료 기준
- 모드 전환 가능
- 앱 재시작 후 모드 유지 가능

---

## 다음 Phase로 넘어가는 규칙
- 화면이 보이는가?
- 요구사항과 맞는가?
- 소스 구조 규칙을 지켰는가?
- 한국어 주석이 충분한가?
- 에러 없이 실행되는가?

이 다 맞아야 다음 Phase 진행.
