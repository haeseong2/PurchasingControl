# 코드 규칙 및 한국어 주석 정책

## 공통 코드 규칙
1. TypeScript 타입을 정확히 쓴다.
2. 화면, 로직, DB를 분리한다.
3. DB 로직은 repository/service로 뺀다.
4. free/premium 분기, trial 분기, notebook 그룹 로직은 각각 한 곳에 모은다.
5. 같은 버튼/패널/카드는 재사용 컴포넌트로 분리한다.
6. any 사용을 피한다.

## 한국어 주석 정책
- 중요한 로직에는 한국어 주석을 반드시 단다.
- 초보자도 이해할 수 있게 자세히 쓴다.
- 특히 아래는 필수 주석 대상이다:
  - 14일 trial 계산 로직
  - free/premium reveal 분기
  - notebook import/export 검증 로직
  - notebook 그룹 생성/단어 배치 로직
  - restorePremium / purchasePremium 흐름

### 예시
```ts
// 사용자가 앱을 처음 설치한 날짜부터 14일 이내인지 확인합니다.
// 14일 이내면 결제하지 않아도 premium 기능을 임시로 열어줍니다.
```

```ts
// 사용자가 선택한 notebook 그룹에 현재 단어를 추가합니다.
// 같은 단어가 이미 들어있으면 중복 삽입하지 않습니다.
```
