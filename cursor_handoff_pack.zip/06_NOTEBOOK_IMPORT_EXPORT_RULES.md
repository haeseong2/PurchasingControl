# notebook Import / Export 규칙

## 목적
- 나만의 단어장만 백업 / 복원
- 학습 진행률은 복원 대상 아님

## notebook에서 가능한 것
- 별표 저장 단어
- 직접 추가 단어
- Excel import한 단어
- 사용자 정의 그룹 배치

## 컬럼 순서
entry_id
word_id
korean
japanese
pronunciation
example_ko
example_ja
memo
source_type
created_at
updated_at

## source_type
- starred_app_word
- imported_custom
- manual_custom

## 중요 규칙
- notebook Excel import/export는 premium만 가능
- 직접 추가는 free도 가능
- import한 단어도 그룹에 배치 가능해야 함
- 템플릿에는 예시 row와 field_guide 시트 포함
