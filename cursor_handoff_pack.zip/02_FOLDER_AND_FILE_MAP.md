# 폴더 / 파일 맵

## app/
화면(route) 폴더
- `_layout.tsx`: 전체 공통 레이아웃
- `index.tsx`: 첫 화면
- `level/[levelId].tsx`: 급수별 Step 목록 화면
- `study/[stepId].tsx`: Step 학습 화면
- `notebook/index.tsx`: 나만의 단어장 메인 화면
- `notebook/group/[groupId].tsx`: 특정 그룹(사용자 정의 Step) 상세 화면
- `notebook/study.tsx`: notebook 학습 화면
- `settings/index.tsx`: 설정 화면
- `premium/index.tsx`: 프리미엄 해금 화면
- `quiz/[stepId].tsx`: placeholder

## src/components/
공통 UI 조각
- LevelCard
- NotebookCard
- StepCard
- WordCard
- RevealAnswerPanel
- BottomActionBar
- ThemeToggle
- PremiumBadge
- SearchBar
- EmptyState
- ScreenContainer
- NotebookGroupCard
- NotebookQuickAddForm

## src/features/
기능별 로직
- levels/
- steps/
- study/
- notebook/
- preferences/
- billing/
- quiz/

## src/features/notebook/
노트북 관련 세부 파일 예시
- notebook.types.ts
- notebook.repository.ts
- notebook.logic.ts
- notebook.groups.repository.ts
- notebook.groups.logic.ts
- notebook.import.ts
- notebook.export.ts
- notebook.validation.ts
- useNotebook.ts
- useNotebookGroups.ts

## src/store/
- study.store.ts
- notebook.store.ts
- preferences.store.ts
- billing.store.ts

## src/db/
- client.ts
- schema.sql
- seed.ts
- migrations/
