# 기술 스택과 선택 이유

## React Native
- iOS/Android를 한 코드베이스로 만들 수 있음
- 모바일 앱 개발에 적합

## Expo
- React Native 초기 세팅을 쉽게 해줌
- 빌드와 테스트가 편함
- App Store / Play Store 배포까지 연결하기 좋음

## TypeScript
- 코드 실수 줄이기 좋음
- Cursor가 생성한 코드 품질 관리에 도움

## Expo Router
- app 폴더 기반으로 화면 라우팅 구성 쉬움

## SQLite
- 서버 없이 로컬 저장 가능
- 학습 앱에 적합
- 오프라인 동작 가능

## Zustand
- 전역 상태 관리가 단순함
- 러닝커브 낮음

## xlsx
- Excel export/import 구현용

## expo-file-system / expo-sharing / expo-document-picker
- 파일 저장/공유/불러오기용

## EAS Build / Submit
- 스토어 배포용 빌드 생성에 사용
