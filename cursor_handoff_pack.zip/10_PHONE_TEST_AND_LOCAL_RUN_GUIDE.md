# 폰 테스트 / 로컬 실행 가이드

1. Node.js 설치
2. 프로젝트 폴더 열기
3. npm install
4. npx expo start
5. 폰에 Expo Go 설치
6. 같은 Wi-Fi 연결
7. QR 스캔으로 폰 실행

코드 수정 후 저장하면 폰에서 바로 반영 확인 가능
