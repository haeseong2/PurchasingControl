# Cursor 부트 프롬프트

아래 내용을 Cursor Agent에 그대로 붙여넣으세요.

먼저 이 폴더 안의 문서를 전부 읽고,
앱의 목표, 화면 구조, free/premium 규칙, 14일 trial 규칙, notebook 그룹 구조, DB 구조, Phase 계획을 한국어로 요약해줘.
코드는 아직 만들지 말고 요약만 해줘.

요약이 끝난 뒤에는 아래 기준을 source of truth로 사용해라.
- 모바일 전용 TOPIK 단어 학습 앱
- free: 1~3급, 정답 보기 뜻만, notebook 사용/직접추가/그룹관리 가능
- premium: 1~6급, 정답 보기 뜻+예문+음성, notebook import/export 가능
- 앱 설치 후 14일은 premium 전체 체험
- 이후 one-time purchase로 premium 해금
- 통계 기능 금지
- 이미지 카드 금지
- 한국어 주석 필수
- notebook은 처음부터 그룹(사용자 정의 Step) 관리 기능 포함
