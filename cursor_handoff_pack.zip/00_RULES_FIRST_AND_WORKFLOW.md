# 규칙부터 읽는 시작 문서

이 문서는 **Cursor에게 프로젝트를 맡기기 전에 반드시 먼저 읽혀야 하는 최상위 기준 문서**입니다.

## 절대 잊으면 안 되는 프로젝트 방향
- 모바일 전용 TOPIK 단어 학습 앱
- 첫 화면: TOPIK 1~6급 + 나만의 단어장
- Step 회독 구조
- 버튼 3개: 알고있음 / 모름 / 정답 보기
- 앱 설치 후 14일 전체 Premium 체험
- 이후 one-time purchase(한 번 결제)로 Premium 해금
- Free / Premium 앱을 따로 만들지 않고 하나의 앱으로 처리
- 통계 기능, 로그인, 서버, 이미지 카드 기능은 **넣지 않는다**

## Free / Premium 핵심 규칙
### Free
- TOPIK 1~3급 사용 가능
- 정답 보기 → 일본어 뜻만
- 나만의 단어장 사용 가능
- 나만의 단어장 학습 가능
- notebook Excel import/export 불가

### Premium
- TOPIK 1~6급 사용 가능
- 정답 보기 → 일본어 뜻 + 예문 + 음성 버튼
- notebook Excel import/export 가능

## 나만의 단어장 핵심 규칙
- 별표한 단어 저장 가능
- 직접 추가 가능
- Excel import 가능
- Excel export 가능 (Premium)
- 사용자 정의 그룹(= step처럼 관리하는 세트) 생성 가능
- 예: 'Step 1', 'Step 2', '시험 전 복습', '동사 세트'
- 각 그룹별로 학습 가능해야 함

## Cursor가 반드시 따를 개발 방식
1. 먼저 문서를 전부 읽고 요약한다.
2. 요약이 맞는지 확인받은 후에만 scaffold를 만든다.
3. 이후에는 Phase 단위로 하나씩 진행한다.
4. 각 Phase 종료 시 구조/규칙/주석/동작을 확인하고 다음 단계로 넘어간다.

## Cursor가 반드시 지켜야 할 코드 규칙
- 화면(app/)와 로직(src/features)은 분리한다.
- DB 쿼리는 화면 파일에 직접 쓰지 않는다.
- free/premium 분기 로직은 billing feature에 모은다.
- notebook 그룹 관리 로직은 notebook feature에 모은다.
- 중요한 코드는 한국어 주석으로 자세히 설명한다.
