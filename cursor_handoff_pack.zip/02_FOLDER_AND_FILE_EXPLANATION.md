# 폴더 / 파일 설명서 (초보자용)

이 문서는 **프로젝트 폴더 구조가 왜 이렇게 나뉘는지**를 개발 처음 보는 사람도 이해할 수 있게 설명합니다.

---

## 루트 폴더
```text
/topik-repetition-app
```
이 폴더가 프로젝트의 본체입니다.
앱과 관련된 모든 소스, 설정, 문서가 여기에 들어갑니다.

---

## app/
```text
app/
  _layout.tsx
  index.tsx
  level/[levelId].tsx
  study/[stepId].tsx
  notebook/index.tsx
  notebook/study.tsx
  settings/index.tsx
  quiz/[stepId].tsx
```

### 이 폴더의 용도
앱에서 “화면으로 이동하는 경로(route)”를 정의하는 폴더입니다.
쉽게 말하면 **어떤 화면이 존재하는지**를 나타냅니다.

### 파일별 설명
- `_layout.tsx`
  - 전체 화면 공통 레이아웃
  - 상단 헤더, 기본 theme 적용 등 공통 구조 담당

- `index.tsx`
  - 앱 첫 화면
  - TOPIK 1급 ~ 6급, 나만의 단어장 카드가 나와야 함

- `level/[levelId].tsx`
  - 특정 급수의 Step 목록을 보여주는 화면
  - 예: 1급 Step 목록

- `study/[stepId].tsx`
  - 특정 Step의 단어 학습 화면
  - 알고있음 / 모름 / 정답 보기 버튼이 있는 핵심 화면

- `notebook/index.tsx`
  - 나만의 단어장 목록 화면
  - 검색 / 정렬 / import/export 버튼 표시

- `notebook/study.tsx`
  - 나만의 단어장 전용 학습 화면
  - 일반 Step 학습과 같은 UX 사용

- `settings/index.tsx`
  - 설정 화면
  - dark/light theme 설정, 데이터 관련 메뉴 등

- `quiz/[stepId].tsx`
  - 현재는 placeholder
  - 나중에 문제 기능 추가 시 사용할 화면

---

## src/
```text
src/
```
이 폴더는 **실제 로직과 재사용 가능한 코드**를 넣는 곳입니다.
화면(app/)과 달리, 기능/상태/데이터 처리를 정리해서 넣습니다.

---

## src/components/
```text
src/components/
```
### 용도
여러 화면에서 반복해서 쓰는 작은 UI 조각을 넣는 폴더입니다.

### 예시
- `LevelCard.tsx`
  - 첫 화면의 “TOPIK 1급 / 2급...” 카드 UI

- `NotebookCard.tsx`
  - 첫 화면 맨 아래 “나만의 단어장” 카드 UI

- `StepCard.tsx`
  - 급수 화면에서 Step 1, Step 2 카드 UI

- `WordCard.tsx`
  - 학습 화면에서 단어를 보여주는 카드 UI

- `RevealAnswerPanel.tsx`
  - 정답 보기 눌렀을 때 뜻/예문을 펼쳐 보여주는 영역

- `BottomActionBar.tsx`
  - 하단 고정 버튼 3개 영역

- `ThemeToggle.tsx`
  - 다크/라이트 전환 버튼

- `SearchBar.tsx`
  - 검색 UI

- `ProgressPill.tsx`
  - 진행률/상태 표시용 작은 UI

- `EmptyState.tsx`
  - 데이터 없을 때 표시하는 빈 화면 UI

- `ScreenContainer.tsx`
  - 각 화면 공통 패딩/배경/스크롤 구조 담당

---

## src/features/
```text
src/features/
```
### 용도
실제 기능 단위로 코드를 나누는 폴더입니다.
“이 기능은 어디 코드인지”를 명확하게 하기 위해 사용합니다.

### 하위 폴더 설명
#### `levels/`
급수 관련 로직
- 급수 목록 가져오기
- 급수 정보 타입 정의

#### `steps/`
Step 관련 로직
- Step 목록 가져오기
- Step 완료 상태 계산
- Step 진행률 계산

#### `study/`
학습 관련 로직
- 알고있음 / 모름 처리
- review queue 반복
- 정답 보기 상태 처리

#### `notebook/`
나만의 단어장 관련 로직
- notebook 목록 불러오기
- import/export
- notebook 학습 로직

#### `preferences/`
설정 관련 로직
- theme 모드 저장/불러오기

#### `quiz/`
문제 기능용 폴더 (현재는 placeholder)

---

## src/store/
```text
src/store/
```
### 용도
앱 전체에서 같이 쓰는 상태(state)를 저장하는 폴더입니다.

### 예시
- `study.store.ts`
  - 현재 학습 진행 상태
- `notebook.store.ts`
  - notebook 관련 화면 상태
- `preferences.store.ts`
  - theme 모드 상태

---

## src/db/
```text
src/db/
```
### 용도
SQLite 연결과 DB 관련 파일을 넣는 폴더입니다.

### 파일 설명
- `client.ts`
  - SQLite 연결 시작 파일
- `schema.sql`
  - 테이블 생성 SQL
- `seed.ts`
  - 초기 데이터 삽입
- `migrations/`
  - 나중에 DB 구조 바뀔 때 업데이트용

---

## assets/
```text
assets/
```
### 용도
앱 아이콘, 스플래시 등 정적 파일을 넣는 폴더입니다.
현재는 이미지 카드 기능을 제거했기 때문에 단어용 이미지 폴더는 필요 없습니다.

---

## docs/
```text
docs/
```
### 용도
프로젝트 내부 참고 문서를 넣는 폴더입니다.
초기에는 handoff pack 안 문서를 그대로 docs 폴더로 복사해도 됩니다.

---

## scripts/
```text
scripts/
```
### 용도
seed 데이터 import, 변환, 자동화 같은 보조 스크립트용 폴더입니다.

### 예시
- `import-words.ts`
  - CSV를 SQLite용 데이터로 넣는 스크립트

---

## 이 문서의 핵심
- `app/` = 화면 파일
- `components/` = 작은 UI 조각
- `features/` = 기능별 로직
- `store/` = 전역 상태
- `db/` = SQLite 관련
- `scripts/` = 데이터 처리 도구
