# Phase 계획 및 완료 기준

## Phase 1 — 프로젝트 세팅
완료 기준:
- Expo + React Native + TypeScript + Expo Router 초기화 완료
- app/ src/ 구조 생성

## Phase 2 — DB 구축
완료 기준:
- SQLite bootstrap 완료
- 제공된 schema 적용
- notebook_groups, notebook_group_items 포함

## Phase 3 — HomeScreen
완료 기준:
- TOPIK 1~6 + My Notebook 표시
- 4~6 잠금 표시 가능
- theme toggle 존재

## Phase 4 — Level / Step 화면
완료 기준:
- Step 목록 표현
- 1~3 접근 가능
- 4~6 free 잠금 가능

## Phase 5 — StudyScreen
완료 기준:
- 알고있음 / 모름 / 정답 보기 동작
- review queue 구현
- free는 뜻만 / premium은 뜻+예문+음성

## Phase 6 — Notebook 기본
완료 기준:
- notebook 목록 / 검색 / 정렬
- 직접 추가 가능
- 그룹 목록 표시 가능

## Phase 7 — Notebook 그룹 관리
완료 기준:
- 그룹 생성 가능
- 단어를 그룹에 넣을 수 있음
- 그룹 상세 화면 존재

## Phase 8 — Notebook 학습
완료 기준:
- notebook 전체 학습 가능
- 그룹별 학습 가능
- 일반 학습과 같은 버튼 구조

## Phase 9 — Excel import/export
완료 기준:
- premium만 import/export 가능
- import 후 notebook에 단어 반영
- import된 단어를 그룹에 배치 가능

## Phase 10 — Theme
완료 기준:
- light/dark/system 적용 및 저장

## Phase 11 — Billing / Premium
완료 기준:
- 14일 trial 계산 가능
- premium 화면 존재
- one-time purchase service 틀 존재
- free/premium/trial 분기 정확
