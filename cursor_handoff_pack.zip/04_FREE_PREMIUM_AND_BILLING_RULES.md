# 무료 / 유료 / Billing 규칙

## Free
- TOPIK 1~3급 접근 가능
- 정답 보기 → 뜻만
- notebook 사용 / 직접 추가 / 그룹 생성 가능
- notebook import/export 불가

## Premium
- TOPIK 1~6급 접근 가능
- 정답 보기 → 뜻 + 예문 + 음성 버튼
- notebook import/export 가능

## Trial
- 앱 설치 후 14일 동안 Premium 전체 기능 무료
- 14일 이후 결제 없으면 Free 전환

## 결제 방식
- 구독 아님
- one-time purchase
- 하나의 앱 안에서 처리
- 앱스토어/구글스토어 공식 결제창 사용

## 플랫폼 처리 규칙
- UI는 공통
- billing service가 iOS / Android 분기 처리
- 화면에서는 purchasePremium() 같은 공통 함수만 호출
