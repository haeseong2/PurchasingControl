-- SQLite schema for TOPIK repetition vocabulary app
-- Includes free/premium gating, 14-day trial, notebook groups, and notebook manual add/import/export.

CREATE TABLE levels (
  level_id INTEGER PRIMARY KEY,
  level_code TEXT NOT NULL UNIQUE,
  level_name TEXT NOT NULL,
  total_word_count INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE steps (
  step_id INTEGER PRIMARY KEY,
  level_id INTEGER NOT NULL,
  step_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  step_type TEXT NOT NULL CHECK(step_type IN ('new','review')),
  range_start INTEGER NOT NULL,
  range_end INTEGER NOT NULL,
  unlock_after_step_id INTEGER,
  pass_condition_type TEXT NOT NULL DEFAULT 'all_known',
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(level_id) REFERENCES levels(level_id)
);

CREATE TABLE words (
  word_id INTEGER PRIMARY KEY,
  level_id INTEGER NOT NULL,
  word_order INTEGER NOT NULL,
  korean TEXT NOT NULL,
  japanese TEXT,
  pronunciation TEXT,
  meaning_short TEXT,
  example_ko TEXT,
  example_ja TEXT,
  audio_key TEXT,
  part_of_speech TEXT,
  tags TEXT,
  difficulty INTEGER,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(level_id) REFERENCES levels(level_id)
);

CREATE TABLE step_words (
  step_id INTEGER NOT NULL,
  word_id INTEGER NOT NULL,
  display_order INTEGER NOT NULL,
  PRIMARY KEY (step_id, word_id),
  FOREIGN KEY(step_id) REFERENCES steps(step_id),
  FOREIGN KEY(word_id) REFERENCES words(word_id)
);

CREATE TABLE user_word_progress (
  progress_id INTEGER PRIMARY KEY,
  device_id TEXT NOT NULL,
  word_id INTEGER NOT NULL,
  known_status TEXT NOT NULL DEFAULT 'unknown' CHECK(known_status IN ('unknown','known','mastered')),
  starred INTEGER NOT NULL DEFAULT 0,
  wrong_count INTEGER NOT NULL DEFAULT 0,
  seen_count INTEGER NOT NULL DEFAULT 0,
  known_count INTEGER NOT NULL DEFAULT 0,
  reveal_count INTEGER NOT NULL DEFAULT 0,
  last_step_id INTEGER,
  last_answered_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(word_id) REFERENCES words(word_id)
);

CREATE TABLE user_step_progress (
  step_progress_id INTEGER PRIMARY KEY,
  device_id TEXT NOT NULL,
  step_id INTEGER NOT NULL,
  total_words INTEGER NOT NULL DEFAULT 0,
  known_words INTEGER NOT NULL DEFAULT 0,
  unknown_words INTEGER NOT NULL DEFAULT 0,
  is_completed INTEGER NOT NULL DEFAULT 0,
  started_at TEXT,
  completed_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(step_id) REFERENCES steps(step_id)
);

-- Notebook entries store both starred app words and manually added/imported words.
CREATE TABLE notebook_entries (
  entry_id TEXT PRIMARY KEY,
  device_id TEXT NOT NULL,
  word_id INTEGER,
  korean TEXT NOT NULL,
  japanese TEXT,
  pronunciation TEXT,
  example_ko TEXT,
  example_ja TEXT,
  memo TEXT,
  source_type TEXT NOT NULL CHECK(source_type IN ('starred_app_word','imported_custom','manual_custom')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(word_id) REFERENCES words(word_id)
);

-- Notebook groups are user-defined step-like sets. Example: 'Step 1', '시험 직전 복습', '동사 세트'.
CREATE TABLE notebook_groups (
  group_id TEXT PRIMARY KEY,
  device_id TEXT NOT NULL,
  group_name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notebook_group_items (
  group_id TEXT NOT NULL,
  entry_id TEXT NOT NULL,
  display_order INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (group_id, entry_id),
  FOREIGN KEY(group_id) REFERENCES notebook_groups(group_id),
  FOREIGN KEY(entry_id) REFERENCES notebook_entries(entry_id)
);

CREATE TABLE notebook_group_progress (
  group_progress_id INTEGER PRIMARY KEY,
  device_id TEXT NOT NULL,
  group_id TEXT NOT NULL,
  total_words INTEGER NOT NULL DEFAULT 0,
  known_words INTEGER NOT NULL DEFAULT 0,
  unknown_words INTEGER NOT NULL DEFAULT 0,
  is_completed INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(group_id) REFERENCES notebook_groups(group_id)
);

CREATE TABLE notebook_transfer_logs (
  transfer_id INTEGER PRIMARY KEY,
  device_id TEXT NOT NULL,
  transfer_type TEXT NOT NULL CHECK(transfer_type IN ('import','export')),
  file_name TEXT,
  row_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'done' CHECK(status IN ('pending','done','failed')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app_preferences (
  preference_id INTEGER PRIMARY KEY,
  device_id TEXT NOT NULL,
  theme_mode TEXT NOT NULL DEFAULT 'system' CHECK(theme_mode IN ('light','dark','system')),
  install_started_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app_entitlements (
  entitlement_id INTEGER PRIMARY KEY,
  device_id TEXT NOT NULL,
  membership_tier TEXT NOT NULL DEFAULT 'free' CHECK(membership_tier IN ('free','premium')),
  premium_started_at TEXT,
  premium_expires_at TEXT,
  purchase_provider TEXT,
  purchase_product_id TEXT,
  purchase_platform TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
