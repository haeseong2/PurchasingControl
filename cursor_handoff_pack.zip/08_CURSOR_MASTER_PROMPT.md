# Cursor 시작용 마스터 프롬프트

아래 내용을 Cursor Agent에 그대로 붙여넣으세요.

---

You are building a production-ready MVP mobile app.

## Project
Build a mobile-only TOPIK repetition vocabulary app for Japanese learners.
Target: iOS + Android.
Use React Native + Expo + TypeScript + Expo Router + SQLite + Zustand.
No backend. No login. No cloud sync.
Notebook backup only via Excel import/export.

## Confirmed feature requirements
1. Home screen must show cards in this exact order:
- TOPIK Level 1
- TOPIK Level 2
- TOPIK Level 3
- TOPIK Level 4
- TOPIK Level 5
- TOPIK Level 6
- My Notebook

2. Support Light / Dark mode with persistent preference.
3. Study screen bottom buttons:
- Known
- Unknown
- Reveal Answer
4. Reveal Answer must show:
- Japanese meaning
- Example sentence(s)
5. Notebook study mode must use the same interaction.
6. Notebook screen must explain Excel template download/import.
7. Excel template must include at least 2 example rows.
8. Images are removed. Use text-focused word cards only.
9. Keep quiz route as placeholder only for future expansion.
10. All important code comments must be written in Korean in a beginner-friendly way.
11. If a future API/external request function exists, comments must explain in Korean what the request is for, what parameters mean, and what it returns.

## Required screens
- HomeScreen
- LevelScreen
- StudyScreen
- NotebookScreen
- NotebookStudyScreen
- SettingsScreen
- QuizScreen placeholder only

## Required features
- TOPIK level cards on home
- My Notebook card on home
- theme toggle + persistence
- step list
- word study session
- known / unknown / reveal answer
- unknown repeat queue
- step completion logic
- star words into notebook
- notebook list + search + sort
- notebook study mode
- Excel export/import

## Constraints
- Build MVP only
- Keep reusable components small
- Keep UI very simple and mobile-first
- Use SQLite schema from provided file
- Level 1 only needs actual seed data now
- Other levels can show placeholder/empty state
- No auth
- No API in MVP

## Output expected now
1. Generate full project scaffold
2. Add dependencies
3. Create routing files
4. Create DB bootstrap files
5. Create feature folders with typed placeholders
6. Add README with run instructions
7. Add Korean comments in important logic files
