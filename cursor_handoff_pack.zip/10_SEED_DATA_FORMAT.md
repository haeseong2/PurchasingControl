# Seed 데이터 포맷

## 목적
단어 원본 데이터는 SQL에 직접 손으로 넣지 않고 CSV/JSON seed 파일로 관리합니다.

## 추천 CSV 컬럼
level
word_id
word_order
korean
japanese
pronunciation
meaning_short
example_ko
example_ja
part_of_speech
tags
difficulty

## 원칙
- word_id는 절대 바꾸지 않음
- 새 단어만 새 word_id 추가
- 번역/예문은 직접 작성 또는 새로 생성
