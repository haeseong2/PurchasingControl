# TOPIK 회독 단어앱 - 시작 안내서

이 폴더는 **개발 처음 하는 사람도 Cursor Agent로 앱을 만들 수 있게** 만든 최종 handoff 패키지입니다.

이 패키지의 목적은 단순히 “설계 문서 모음”이 아니라,
**Cursor에게 무엇을 읽히고, 어떤 순서로 개발시키고, 각 단계가 끝났을 때 무엇을 확인해야 하는지**까지 알려주는 것입니다.

---

## 이 패키지로 만들 앱
- 모바일 전용 TOPIK 단어 학습 앱
- 첫 화면에 TOPIK 1급 ~ 6급과 나만의 단어장 카드 표시
- Step 기반 회독 학습
- 버튼 3개: `알고있음 / 모름 / 정답 보기`
- `정답 보기` 누르면 일본어 뜻 + 예문 표시
- 별표(★) 누르면 나만의 단어장에 저장
- 나만의 단어장도 같은 학습 방식 사용
- 다크/라이트 배경 테마 지원
- Excel 다운로드/불러오기 지원
- 서버 없이 로컬 SQLite로 저장

---

## 이 폴더를 어떻게 쓰는가
### 순서
1. 이 파일부터 읽는다.
2. `01_PROJECT_OVERVIEW.md` 를 읽는다.
3. `02_FOLDER_AND_FILE_EXPLANATION.md` 를 읽는다.
4. `08_CURSOR_MASTER_PROMPT.md` 를 Cursor Agent에 넣는다.
5. `09_PHASE_GUIDE_AND_ACCEPTANCE.md` 를 보고 Phase 1부터 순서대로 진행한다.

---

## 가장 중요한 원칙
- 한 번에 다 만들라고 하지 않는다.
- 반드시 Phase 단위로 진행한다.
- 각 Phase가 끝날 때마다 화면/파일/로직을 확인한다.
- 맞으면 다음 Phase로 간다.
- 틀리면 수정시키고 나서 다음 Phase로 간다.

---

## 이 폴더 안의 핵심 파일
- `01_PROJECT_OVERVIEW.md` → 앱 전체 목표와 기능 정리
- `02_FOLDER_AND_FILE_EXPLANATION.md` → 폴더/파일이 왜 필요한지 초보자용 설명
- `03_TECH_STACK_AND_REASON.md` → 기술 스택과 이유
- `04_DATABASE_SCHEMA.sql` → SQLite 테이블 구조
- `05_NOTEBOOK_IMPORT_EXPORT_SPEC.md` → Excel 규격
- `06_DATA_UPDATE_RULES.md` → 업데이트 시 데이터 유지 규칙
- `07_CODE_RULES_AND_KOREAN_COMMENTS.md` → 소스 코드 규칙, 주석 규칙
- `08_CURSOR_MASTER_PROMPT.md` → Cursor에게 처음 넣는 시작 지시문
- `09_PHASE_GUIDE_AND_ACCEPTANCE.md` → Phase 순서, 각 단계 완료 기준, 다음 단계로 넘어가는 조건
- `10_SEED_DATA_FORMAT.md` → 단어 CSV 규격
- `11_THEME_RULES.md` → 다크/라이트 테마 규칙
- `12_SETTINGS_AND_EMPTY_STATE_GUIDE.md` → 설정 화면/빈 화면 처리 규칙
- `13_FUTURE_API_COMMENT_GUIDE.md` → 나중에 API 붙일 때 한국어 주석 작성 규칙

---

## 짧은 요약
이 패키지는 **“개발 처음 보는 사람도 Cursor를 감독하면서 단계별로 앱을 만들 수 있게 하는 설명서 + 기준서 + prompt 팩”** 입니다.
